String githubUri =
    "https://automatic-rotary-phone-j9v6vxwpv9g3qxvr-8080.app.github.dev";

String localUri = "http://192.168.1.87";
